#!/bin/bash

#/usr/local/bin/gunicorn jobs.wsgi:application -w 2 -b :8000

#gunicorn jobs.wsgi:application --bind 0.0.0.0:8000
